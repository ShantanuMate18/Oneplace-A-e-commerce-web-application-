import React ,{useState} from 'react';
import { removeUserSession } from '../Services/AuthService';
export default function Logout() {

 

return (
    <div>
      <h4>Logout Done</h4>
    </div>
  );
 }
 