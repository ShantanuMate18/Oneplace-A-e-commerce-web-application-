package com.example.demo.service;

public record AuthResponse(Long id, String name) {
}